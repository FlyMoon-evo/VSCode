# Change Log

0.0.1
- Initial version

[See here for the latest release notes.](https://github.com/microsoft/vscode-docs/blob/master/remote-release-notes)